import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String #Tipo de mensaje recibido en el topico robot_bot_teclas
import serial
import time
import numpy as np
ser = serial.Serial("/dev/ttyACM0", baudrate=230400) #Modificar el puerto serie de ser necesario
ser.flush()
#dar permiso al puerto sudo chmod 666 /dev/ttyUSB0
from threading import Thread  #Crear threads para correr dos cosas simultaneamenteaaaaa
from time import sleep
import math
global lista_a
lista_a = [0,0]
global read_serial
read_serial = ""
global posiciones
posiciones = [0.0, 0.0, 0.0]
global control 
control = False
r = 3 #Radio de las ruedas en cm
l = 25 #distancia entre ruedas
global pos_ant
pos_ant = [0,0,0] #x,y,theta

pos_act = [0,0,0]

def calcular_pos(angulos):
    #Siempre uso como posicion anterior cero para  obtener de una vez el delta de posicion
    # Angulos contiene [contador, angulo1, angulo2, DeltaT]
    global pos_ant
    global pos_act
    #pos_act = [0,0,0] #x,y,theta
    delta_ang = [np.deg2rad(float(angulos[1])),np.deg2rad(float(angulos[2]))] #Delta theta de cada llanta
    delta_t = float(angulos[3]) #DeltaT del movimiento
    sigmas = [delta_ang[0]/delta_t, delta_ang[1]/delta_t] #velocidad angular de cada rueda
    velocidades = [r*sigmas[0], r*sigmas[1]] #Velocidad lineal de cada rueda
    
    xr = (velocidades[0]+velocidades[1])/2 #Velocidad lineal del robot en X en el marco local
    yr = 0  #Velocidad lineal del robot en Y en el marco local
    wr = (r*sigmas[0]/l) - (r*sigmas[1]/l) #Velocidad angular del robot en el marco local
    x_punto = xr*math.cos(wr)-yr*math.sin(wr)
    y_punto = xr*math.sin(wr)+yr*math.cos(wr)
    w_punto = wr

    # Distancia a ICC
    R = (l/2)*(velocidades[0]+velocidades[1])/(velocidades[1]-velocidades[0])
    
    # ICC
    iccx = pos_act[0] - R*math.sin(pos_act[2])
    iccy = pos_act[1]  + R*math.cos(pos_act[2])

    # Cinematica Directa
    pos_fin_x = (pos_act[0] - iccx)*math.cos(wr*delta_t) - (pos_act[1] - iccy)*math.sin(wr*delta_t)+iccx
    pos_fin_y  = (pos_act[0] - iccx)*math.sin(wr*delta_t) + (pos_act[1] - iccy)*math.cos(wr*delta_t)+iccy
    pos_fin_theta  = pos_act[2] + wr*delta_t

    # actualizar condicions de frontera
    pos_act = [pos_fin_x, pos_fin_y, pos_fin_theta]

    print(pos_act)
    print('') 
    return pos_act


class RobotCmdVelSubscriber(Node):

    def __init__(self):
        super().__init__('nodo_prueba')
        self.subscription = self.create_subscription( Twist,'robot_teclas', self.listener_callback,10)
        self.publisher_ = self.create_publisher( Twist,'posiciones', 10)
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def listener_callback(self, msg):
        global lista_a
        global read_serial
        global x
        global y
        global control
        global posiciones
        lineal = int(msg.linear.x)
        angular = int(msg.angular.z)
        lista_n = [lineal, angular]

        if(lista_n != lista_a):
            ser.write(f"{lineal},{angular}\n".encode())
            control = True
            time.sleep(0.1)
        lista_a = lista_n

        if ser.inWaiting() > 0:
            entrada = ser.readline().decode('utf-8').rstrip()
            angulos = entrada.split(',')
            print(angulos)
            ser.flush()
            posiciones = calcular_pos(angulos)
            
    def timer_callback(self):
        global posiciones
        msg_angulos = Twist()
        msg_angulos.linear.x = posiciones[0] #Variacion en x
        msg_angulos.linear.y = posiciones[1] # Variacion en y
        msg_angulos.linear.z = posiciones[2] # Variacion en theta
        self.publisher_.publish(msg_angulos)
        #self.get_logger().info('Pos actualizada')






def main(args=None):
    rclpy.init(args=args)
    #t = Thread(target=leer_encoders) #inicia un segundo hilo en el cual va a correr la interfaz
    #t.start() #inicia la interfaz
    robot_cmd_vel_subscriber = RobotCmdVelSubscriber()
    rclpy.spin(robot_cmd_vel_subscriber)
    #t.join()
    rclpy.shutdown()

if __name__ == '__main__':
    main()