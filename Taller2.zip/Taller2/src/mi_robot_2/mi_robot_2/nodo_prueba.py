import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String #Tipo de mensaje recibido en el topico robot_bot_teclas
import serial
import time
ser = serial.Serial("/dev/ttyACM0", baudrate=230400) #Modificar el puerto serie de ser necesario
ser.flush()
#dar permiso al puerto sudo chmod 666 /dev/ttyUSB0
from threading import Thread  #Crear threads para correr dos cosas simultaneamenteaaaaa
from time import sleep
import math
global lista_a
lista_a = [0,0]
global read_serial
read_serial = ""
global posiciones
posiciones = [0.0, 0.0, 0.0]
global control 
control = False
r = 3 #Radio de las ruedas en cm
l = 25 #distancia entre ruedas
global pos_ant
pos_ant = [0,0,0] #x,y,theta

def calcular_pos(angulos):
    #Siempre uso como posicion anterior cero para  obtener de una vez el delta de posicion
    # Angulos contiene [contador, angulo1, angulo2, DeltaT]
    global pos_ant
    pos_act = [0,0,0] #x,y,theta
    delta_ang = [float(angulos[1]),float(angulos[2])] #Delta theta de cada llanta
    delta_t = float(angulos[3]) #DeltaT del movimiento
    sigmas = [delta_ang[0]/delta_t, delta_ang[1]/delta_t] #velocidad angular de cada rueda
    velocidades = [r*sigmas[0], r*sigmas[1]] #Velocidad lineal de cada rueda
    v = (velocidades[0]+velocidades[1])/2 #Velocidad lineal del robot en el marco local
    wr = (r*sigmas[0]/l) - (r*sigmas[1]/l) #Velocidad angular del robot en el marco local
    pos_act[0] = pos_ant[0] + v*math.cos(wr*delta_t)*delta_t
    pos_act[1] = pos_ant[1] + v*math.sin(wr*delta_t)*delta_t
    pos_act[2] = pos_ant[2] + wr*delta_t
    #Siempre uso posicion anterior como 0 para tomar unicamnete la variacion en cada eje y en theta
    print(pos_act) 
    return pos_act


class RobotCmdVelSubscriber(Node):

    def __init__(self):
        super().__init__('nodo_prueba')
        self.subscription = self.create_subscription( Twist,'robot_teclas', self.listener_callback,10)
        self.publisher_ = self.create_publisher( Twist,'posiciones', 10)
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def listener_callback(self, msg):
        global lista_a
        global read_serial
        global x
        global y
        global control
        global posiciones
        lineal = int(msg.linear.x)
        angular = int(msg.angular.z)
        lista_n = [lineal, angular]

        if(lista_n != lista_a):
            ser.write(f"{lineal},{angular}\n".encode())
            control = True
            time.sleep(0.1)
        lista_a = lista_n

        if ser.inWaiting() > 0:
            entrada = ser.readline().decode('utf-8').rstrip()
            angulos = entrada.split(',')
            print(angulos)
            ser.flush()
            posiciones = calcular_pos(angulos)
            
    def timer_callback(self):
        global posiciones
        msg_angulos = Twist()
        msg_angulos.linear.x = posiciones[0] #Variacion en x
        msg_angulos.linear.y = posiciones[1] # Variacion en y
        msg_angulos.linear.z = posiciones[2] # Variacion en theta
        self.publisher_.publish(msg_angulos)
        #self.get_logger().info('Pos actualizada')






def main(args=None):
    rclpy.init(args=args)
    #t = Thread(target=leer_encoders) #inicia un segundo hilo en el cual va a correr la interfaz
    #t.start() #inicia la interfaz
    robot_cmd_vel_subscriber = RobotCmdVelSubscriber()
    rclpy.spin(robot_cmd_vel_subscriber)
    #t.join()
    rclpy.shutdown()

if __name__ == '__main__':
    main()